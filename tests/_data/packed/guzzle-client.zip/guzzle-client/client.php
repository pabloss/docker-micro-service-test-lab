<?php
declare(strict_types=1);
require_once 'vendor/autoload.php';

$client = new \GuzzleHttp\Client();
$response = $client->request('POST', 'http://service-test-lab-new.local/endpoint', [
    'body' => 'Hej udało się !',
    'http_errors' => false,
]);

echo $response->getStatusCode(); // 200
echo $response->getHeaderLine('content-type'); // 'application/json; charset=utf8'
//echo $response->getBody(); // '{"id": 1420053, "name": "guzzle", ...}'
