<?php
declare(strict_types=1);

namespace App\Controller;

use Symfony\Component\HttpClient\HttpClient;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

class EchoController
{
    /**
     * @Route("/echo")
     * @param Request $request
     * @return Response
     * @throws ClientExceptionInterface
     * @throws RedirectionExceptionInterface
     * @throws ServerExceptionInterface
     * @throws TransportExceptionInterface
     */
    public function echo(Request $request)
    {
        $client = HttpClient::create();
        // http://localhost:3333/index.php/echo
        $response = $client->request('POST', 'http://172.17.0.1:2222/index.php/echo', [
            'body' => $request->getContent(false)
        ]);

        return new Response($request->getContent(). " byłem w a " . $response->getContent(false));
    }
}
